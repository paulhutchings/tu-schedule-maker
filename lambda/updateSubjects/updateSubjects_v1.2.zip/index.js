const HTTPS = require(https);
const { PROMISIFY } = require('util');
const GET = PROMISIFY(HTTPS.get);
const CHEERIO = require('cheerio');
const AWS = require('aws-sdk');

const URL = 'http://bulletin.temple.edu/courses/';
const SELECTOR = 'a.sitemaplink';
const DB = new AWS.DynamoDB.DocumentClient();

exports.handler = main();

//FUNCTIONS

//The main method of the program
async function main(){ 
    try {
        console.log('Sending GET request...');
        var response = await GET(URL);
        console.log('Request successful');
        var subjects = await parseSubjects(response.data);
        console.log('Writing to database...');
        await writeItems(subjects);
        // FS.writeFile('./lambda/test/subjects.json', JSON.stringify(subjects), (err) => console.log(err));
        console.log('Complete');
    } catch (error) {
        console.log(error);
    }
}

//Extracts the subject abbreviations from the HTML
async function parseSubjects(data){
    console.log('Loading response data into HTML...');
    var $ = CHEERIO.load(data);
    var subjectList = $(SELECTOR);
    var subjects = [];

    console.log('Extracting subjects...');
    subjectList.each((i, element) => {
        var entry = $(element).text();
        var subject = entry.slice(
                entry.lastIndexOf('(') + 1, 
                entry.length - 1);
        subjects.push(subject);
    });

    return subjects;
}

//Wraps each item in a PUT request, then writes to the DynamoDB table in batches of 25
async function writeItems(items){
    var requests = items.map(item => {
        return {
            PutRequest: {
                Item: {
                    subject: item
                }
            }
        };  
    });

    for (let index = 0; index < requests.length; index += 25) {
        var subset = requests.slice(index, 
                (index + 25) > requests.length 
                ? requests.length 
                : index + 25);
        var params = {
            RequestItems: {
                'subjects-test': subset
            }
        };

        console.log(await DB.batchWrite(params));      
    }  
}